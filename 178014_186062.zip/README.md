# Trabalho 1 - EA876

## Como utilizar

A pasta `src/` contém os arquivos fonte (`main.l` e `main.y`), a pasta `doc/` contém o relatório `relatorio.pdf` e a pasta `test/` contém 20 testes (arquivos .in).

Podemos utilizar o `Makefile` para as seguintes operações:

- `make`: Compila o programa para o arquivo `main`
- `make out`: Gera arquivos assembly .s para os arquivos em `test/`
- `make test`: Executa o script de teste cedido pelo professor da disciplina com os arquivos em `test/`
